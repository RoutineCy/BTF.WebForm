﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Model
{
    public class Game_info
    {
        public int? gtid { get; set; }

        public int? Sid { get; set; }

        public int gState { get; set; }

        public string gName { get; set; }

        public string name { get; set; }

        public string sName { get; set; }

        public double gPrice { get; set; }
    }
}
